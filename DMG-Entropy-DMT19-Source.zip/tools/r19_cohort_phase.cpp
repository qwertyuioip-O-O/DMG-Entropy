#include "r19_g10index_model.hpp"

struct CohortPhaseClock {
 using Clock=std::chrono::steady_clock;
 std::array<double,3> seconds{};std::array<uint64_t,3> plies{};
 int active=-1;Clock::time_point stamp;
 void enter(unsigned stage){
  ++plies[stage];if(active==int(stage))return;
  auto now=Clock::now();if(active>=0)seconds[active]+=std::chrono::duration<double>(now-stamp).count();active=int(stage);stamp=now;
 }
 void stop(){if(active<0)return;auto now=Clock::now();seconds[active]+=std::chrono::duration<double>(now-stamp).count();active=-1;}
};
static CohortPhaseClock* cohort_phase_clock=nullptr;

V6Archive encode19(const Games&games,unsigned mode,const Table19&t,MidDiagnostics*diag=nullptr,std::ostream*examples=nullptr){
 if(mode>4||games.size()>100000)fail("mode/count18");bool active=std::any_of(t.begin(),t.end(),[](int v){return v!=0;});if(diag)*diag={};Context18 c;ArithmeticEncoder coder;uint64_t total=0;
 for(const auto&g:games){if(g.size()>1000000||(total+=g.size())>300000000)fail("length18");Position p=Position::standard();Move prev{},own[2]{};bool hp=false,ho[2]={};for(unsigned ply=0;ply<g.size();++ply){unsigned stage=V7Patterns::phase(p,ply),side=p.side;if(cohort_phase_clock)cohort_phase_clock->enter(stage);auto s=step19(p,hp?&prev:nullptr,ho[side]?&own[side]:nullptr,ply,stage,c,mode,t,active);unsigned ix=index_of(s.base.moves,g[ply]);
  if(examples&&stage==1){auto z=base19(p,hp?&prev:nullptr,ho[side]?&own[side]:nullptr,ply,c);auto put=[&](unsigned v){examples->put(char(v));examples->put(char(v>>8));};put(z.base.moves.size);put(ix);for(unsigned i=0;i<z.base.moves.size;++i){put(z.coded.weights[i]);for(auto k:z.r12_features[i])put(168*bucket18(z.base.flags[i])+k);unsigned piece=unsigned(abs_piece(p.board[z.base.moves.a[i].m.from])-1);put(response19(z.base.flags[i],piece));put(direct19(z.base.moves.a[i].m.to,piece));}}
  mid_record(diag,stage,s,ix);coder.put(v6_before(s.coded,ix),s.coded.weights[ix],s.coded.total);observe19(c,p,s,ix,ply,stage,mode);p.apply_unchecked(g[ply]);own[side]=g[ply];ho[side]=true;prev=g[ply];hp=true;
 }if(cohort_phase_clock)cohort_phase_clock->stop();}auto payload=total?coder.finish():EntropyPayload{};std::vector<uint8_t>b={'D','1','9','P',1,uint8_t(mode)};auto id=id19(t);for(int k=0;k<4;++k)b.push_back(uint8_t(id>>(8*k)));v6_varint(b,uint32_t(games.size()));for(auto&g:games)v6_varint(b,uint32_t(g.size()));v6_varint(b,payload.bit_count);uint64_t framing=b.size()+4;b.insert(b.end(),payload.bytes.begin(),payload.bytes.end());auto crc=v6_crc(b.data(),b.size());for(int k=0;k<4;++k)b.push_back(uint8_t(crc>>(8*k)));return {std::move(b),payload.bit_count,framing};
}
Games decode19(const std::vector<uint8_t>&b,const Table19&t){
 if(b.size()<16||std::string(b.begin(),b.begin()+4)!="D19P"||b[4]!=1||b[5]>4)fail("header18");uint32_t crc=0,id=0;for(int k=0;k<4;++k){crc|=uint32_t(b[b.size()-4+k])<<(8*k);id|=uint32_t(b[6+k])<<(8*k);}if(crc!=v6_crc(b.data(),b.size()-4)||id!=id19(t))fail("CRC/model18");size_t off=10;unsigned count=v6_unvar(b,off);if(count>100000)fail("count18");std::vector<uint32_t>lens;uint64_t total=0;for(unsigned j=0;j<count;++j){auto n=v6_unvar(b,off);if(n>1000000||(total+=n)>300000000)fail("length18");lens.push_back(n);}auto bits=v6_unvar(b,off);if(off+4>b.size()||(uint64_t(bits)+7)/8!=b.size()-off-4||(total&&!bits))fail("payload19");ArithmeticDecoder coder(b.data()+off,bits);Context18 c;Games games;bool active=std::any_of(t.begin(),t.end(),[](int v){return v!=0;});
 for(auto len:lens){Position p=Position::standard();Move prev{},own[2]{};bool hp=false,ho[2]={};std::vector<Move>g;for(unsigned ply=0;ply<len;++ply){unsigned stage=V7Patterns::phase(p,ply),side=p.side;if(cohort_phase_clock)cohort_phase_clock->enter(stage);auto s=step19(p,hp?&prev:nullptr,ho[side]?&own[side]:nullptr,ply,stage,c,b[5],t,active);uint32_t before=0;auto ix=v6_select(s.coded,s.base.moves.size,coder.target(s.coded.total),before);coder.take(before,s.coded.weights[ix],s.coded.total);auto m=s.base.moves.a[ix].m;observe19(c,p,s,ix,ply,stage,b[5]);p.apply_unchecked(m);own[side]=m;ho[side]=true;prev=m;hp=true;g.push_back(m);}if(cohort_phase_clock)cohort_phase_clock->stop();games.push_back(std::move(g));}return games;
}int main(int argc,char**argv){try{
 if(argc<4)fail("export BUNDLE OUT | eval BUNDLE TABLE MODES | speed BUNDLE TABLE MODE | pack BUNDLE TABLE MODE OUT | unpack FILE TABLE OUT | test BUNDLE TABLE");std::string cmd=argv[1];
 if(cmd=="unpack"){if(argc!=5)fail("args");std::ifstream f(argv[2],std::ios::binary);std::vector<uint8_t>b((std::istreambuf_iterator<char>(f)),{});auto games=decode19(b,load19(argv[3]));std::ofstream out(argv[4]);for(auto&g:games){for(auto m:g)out<<to_uci(m)<<' ';out<<'\n';}if(!out)fail("write18");return 0;}
 auto games=read_games(argv[2]);uint64_t plies=0;for(auto&g:games)plies+=g.size();if(cmd=="export"){std::ofstream f(argv[3],std::ios::binary);encode19(games,0,{},nullptr,&f);if(!f)fail("export18");return 0;}auto table=load19(argv[3]);if(cmd=="analyze"){analyze19(games);return 0;}

 if(cmd=="phase"){
  if(argc!=5)fail("phase BUNDLE TABLE REPETITIONS");unsigned reps=std::stoul(argv[4]);if(!reps||reps>20)fail("phase repetitions");
  MidDiagnostics diag;auto reference=encode19(games,3,table,&diag);if(decode19(reference.bytes,table)!=games)fail("phase warmup");
  std::cout<<"iteration,stage,plies,cdf_bits,encode_seconds,decode_seconds,payload_bits,archive_bytes\n"<<std::setprecision(17);
  for(unsigned rep=0;rep<reps;++rep){
   CohortPhaseClock enc,dec;cohort_phase_clock=&enc;auto encoded=encode19(games,3,table);cohort_phase_clock=nullptr;
   if(encoded.bytes!=reference.bytes)fail("phase encoded byte mismatch");
   cohort_phase_clock=&dec;auto decoded=decode19(reference.bytes,table);cohort_phase_clock=nullptr;if(decoded!=games)fail("phase decoded mismatch");
   for(unsigned phase=0;phase<3;++phase){if(enc.plies[phase]!=diag.phase[phase].moves||dec.plies[phase]!=enc.plies[phase])fail("phase count mismatch");
    std::cout<<rep<<','<<phase<<','<<enc.plies[phase]<<','<<diag.phase[phase].logloss<<','<<enc.seconds[phase]<<','<<dec.seconds[phase]<<','<<reference.payload_bits<<','<<reference.bytes.size()<<'\n';
   }
  }return 0;
 }
 if(cmd=="test"){unsigned checks=0;for(unsigned i=1;i<513;++i){if(dmt19_exp[i]<=dmt19_exp[i-1])fail("LUT monotonic19");++checks;}for(int k=-128;k<=128;++k){if(dmt19_exp[k+256]!=v8_exp2_lut[k+128])fail("LUT reference19");++checks;}if(dmt19_exp[0]!=256||dmt19_exp[512]!=65536)fail("LUT bounds19");++checks;auto reject=[&](const auto&b,const auto&t){try{decode19(b,t);}catch(const std::exception&){++checks;return;}fail("accepted18");};for(const auto&g:std::vector<Games>{Games{},Games{{}},Games{parse_moves("e2e4")},games})for(unsigned m=0;m<=4;++m){auto a=encode19(g,m,table);if(decode19(a.bytes,table)!=g)fail("roundtrip18");++checks;auto bad=a.bytes;bad.back()^=1;reject(bad,table);auto wrong=table;wrong[0]=wrong[0]==128?127:wrong[0]+1;reject(a.bytes,wrong);for(size_t n=0;n<a.bytes.size();++n)if(n<20||n+8>=a.bytes.size())reject(std::vector<uint8_t>(a.bytes.begin(),a.bytes.begin()+n),table);}
 auto a=encode19(games,0,table),b=encode18(games,9,dmt18_prior_v1);if(a.payload_bits!=b.payload_bits||!std::equal(a.bytes.begin()+a.framing_bytes-4,a.bytes.end()-4,b.bytes.begin()+b.framing_bytes-4,b.bytes.end()-4))fail("R18 identity18");++checks;std::cout<<"PASS "<<checks<<" checks; modes0..4, empty, CRC, truncation, wrong-table, R18 identity\n";return 0;}
 if(cmd=="blocks"){std::cout<<"block_size,mode,files,bits,bytes,mid_n,mid_cdf,roundtrip\n"<<std::setprecision(12);for(unsigned size:{1u,10u,30u,120u,unsigned(games.size())}){if(!size)continue;for(unsigned m:{0u,2u,3u,4u}){uint64_t bits=0,bytes=0,n=0,files=0;double loss=0;for(size_t begin=0;begin<games.size();begin+=size){Games g(games.begin()+begin,games.begin()+std::min(games.size(),begin+size));MidDiagnostics d;auto a=encode19(g,m,table,&d);if(decode19(a.bytes,table)!=g)fail("blocks18");++files;bits+=a.payload_bits;bytes+=a.bytes.size();n+=d.phase[1].moves;loss+=d.phase[1].logloss;}std::cout<<size<<','<<m<<','<<files<<','<<bits<<','<<bytes<<','<<n<<','<<(n?loss/n:0)<<",PASS\n"<<std::flush;}}return 0;}
 if(cmd=="pack"){if(argc!=6)fail("args");auto a=encode19(games,std::stoul(argv[4]),table);if(decode19(a.bytes,table)!=games)fail("pack18");std::ofstream f(argv[5],std::ios::binary);f.write((char*)a.bytes.data(),a.bytes.size());if(!f)fail("write18");return 0;}
 if(cmd=="speed"){if(argc!=5)fail("args");unsigned m=std::stoul(argv[4]);auto a=encode19(games,m,table);if(decode19(a.bytes,table)!=games)fail("warm18");auto t0=std::chrono::steady_clock::now();for(int k=0;k<3;++k)if(encode19(games,m,table).bytes!=a.bytes)fail("determinism18");auto t1=std::chrono::steady_clock::now();for(int k=0;k<3;++k)if(decode19(a.bytes,table)!=games)fail("decode19");auto t2=std::chrono::steady_clock::now();std::cout<<m<<','<<plies<<','<<std::chrono::duration<double>(t1-t0).count()/3<<','<<std::chrono::duration<double>(t2-t1).count()/3<<'\n';return 0;}
 if(cmd!="eval"||argc!=5)fail("eval args");std::cout<<"mode,games,plies,bits,bytes,mid_n,mid_cdf,open_cdf,end_cdf,roundtrip\n"<<std::setprecision(12);std::stringstream modes(argv[4]);std::string text;while(std::getline(modes,text,',')){unsigned m=std::stoul(text);MidDiagnostics d;auto a=encode19(games,m,table,&d);if(decode19(a.bytes,table)!=games||encode19(games,m,table).bytes!=a.bytes)fail("eval18");std::cout<<m<<','<<games.size()<<','<<plies<<','<<a.payload_bits<<','<<a.bytes.size()<<','<<d.phase[1].moves;for(unsigned stage:{1,0,2})std::cout<<','<<(d.phase[stage].moves?d.phase[stage].logloss/d.phase[stage].moves:0);std::cout<<",PASS\n"<<std::flush;}
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
