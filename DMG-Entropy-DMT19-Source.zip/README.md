# DMG-Entropy

DMG-Entropy is a C++20 research project for lossless compression of chess move sequences.

This archive contains the DMT19 research snapshot: codec sources, compatibility tests, examples, benchmark tools, and experiment reports. The codec stores move sequences and does not preserve PGN tags, comments, variations, or text formatting.

## Build and test

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure
```

See README-Cohorts-20261023-KO.md, README-R19.md, and the current dated benchmark reports for methodologies and limitations. Results depend on dataset, hardware, compiler, and measurement path.

Raw game corpora, local benchmark binaries, and build outputs are excluded. Historical source and experiment notes are retained for context.
